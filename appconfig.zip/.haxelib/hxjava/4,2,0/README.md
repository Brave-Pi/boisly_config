hxjava
======

[![TravisCI Build Status](https://travis-ci.org/HaxeFoundation/hxjava.svg?branch=master)](https://travis-ci.org/HaxeFoundation/hxjava)

Haxe Java support library. Build scripts and support code.
