build-tool-base
===============

Base project for hxcs and hxjava build tools